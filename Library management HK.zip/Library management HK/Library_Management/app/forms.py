from django import forms
from .models import Author, Book, BorrowRecord


class Author_Form(forms.ModelForm):
    class Meta:
        model = Author
        fields = ['name', 'email', 'bio']

class Book_forms(forms.ModelForm):
    class Meta:
        model = Book
        fields = ['title','genre','published_date','author']

class Borrow_form(forms.ModelForm):
    class Meta:
        model = BorrowRecord
        fields = ['user_name','Book','borrow_date', 'return_date']