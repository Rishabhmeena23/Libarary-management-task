from django.views.generic import CreateView, ListView, View
from .models import Author, Book, BorrowRecord
from .forms import Author_Form, Book_forms, Borrow_form
from django.shortcuts import HttpResponse,render
from django.core.paginator import Paginator
import openpyxl

# Create your views here.

class Index(View):
    def get(self,request):
        return render(request,'index.html')

class Addauthor(CreateView):
    model = Author.objects.all()
    form_class = Author_Form
    template_name = 'app/form.html'
    success_url = '/authors'

class Authorlist(ListView):
    model = Author
    template_name = 'app/list.html'
    paginate_by = 5

class AddBook(CreateView):
    model = Book
    form_class = Book_forms
    template_name = 'app/form.html'
    success_url = '/books'

class BookList(ListView):
    model = Book
    template_name = 'app/list.html'
    paginate_by = 5

class AdddBorrowDate(CreateView):
    model = BorrowRecord
    form_class = Borrow_form
    template_name = 'app/form.html'
    success_url = '/borrows'

class Borrowlist(ListView):
    model = BorrowRecord
    template_name = 'app/list.html'
    paginate_by = 5


class ExcelView(View):
    def get(self, request):
        wb = openpyxl.Workbook()
        del wb['Sheet']

        ws1 = wb.create_sheet('Authors')
        ws1.append(['ID', 'Name', 'Email', 'Bio'])
        for author in Author.objects.all():
            ws1.append([author.id, author.name, author.email, author.bio])

        ws2 = wb.create_sheet('Books')
        ws2.append(['ID', 'Title', 'Genre', 'Published Date', 'Author'])
        for book in Book.objects.all():
            ws2.append([book.id, book.title, book.genre, book.published_date, book.author.name])

        ws3 = wb.create_sheet('BorrowRecords')
        ws3.append(['ID', 'User Name', 'Book', 'Borrow Date', 'Return Date'])
        for record in BorrowRecord.objects.all():
            ws3.append([record.id, record.user_name, record.Book.title, record.borrow_date, record.return_date])

        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = 'attachment; filename=library_data.xlsx'
        wb.save(response)
        return response
